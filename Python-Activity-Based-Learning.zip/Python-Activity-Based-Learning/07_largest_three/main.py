values=[float(input(f"Number {i}: ")) for i in range(1,4)]
print("Largest:",max(values))
