n=int(input("Nonnegative integer: "))
if n<0: print("Undefined for negative numbers")
else:
    result=1
    for i in range(2,n+1): result*=i
    print(result)
