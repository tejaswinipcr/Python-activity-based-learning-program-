s=input("Text: ")
clean="".join(c.lower() for c in s if c.isalnum())
print("Palindrome" if clean==clean[::-1] else "Not palindrome")
