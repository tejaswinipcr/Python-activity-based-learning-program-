# Case Study 5: Fibonacci Sequence

## Problem Statement
Develop a Python program to perform: fibonacci sequence.

## Objectives
- Accept suitable input.
- Apply the appropriate Python logic.
- Display a clear result.

## Assumptions
- The user enters values in the requested format.
- Python 3.9 or later is available.

## Algorithm
1. Start.
2. Read the input.
3. Validate or process the input using the program logic.
4. Display the result.
5. Stop.

## Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[/Read input/]
    B --> C[Validate and process input]
    C --> D[/Display result/]
    D --> E([Stop])
```

## Pseudocode
```text
BEGIN
  READ input
  APPLY fibonacci sequence logic
  PRINT result
END
```

## Python Source Code
See `main.py`.

## Test Cases
| Example input | Expected output |
|---|---|
| 5 | 0 1 1 2 3 |

## Output Screenshot
See `output.png` for an illustrative console-style example output (not an actual IDE screenshot).

## Conclusion
The program demonstrates basic Python input, processing, and output for fibonacci sequence.
