text=input("Text: ")
print("Vowels:",sum(c.lower() in "aeiou" for c in text))
